// src/services/movieApi.js
// API service to fetch movie data from TMDB, OMDb, and streaming services

const TMDB_BASE_URL = 'https://api.themoviedb.org/3';
const TMDB_IMAGE_BASE = 'https://image.tmdb.org/t/p';
const OMDB_BASE_URL = 'http://www.omdbapi.com';
const WATCHMODE_BASE_URL = 'https://api.watchmode.com/v1';

// Get API keys from environment variables
const TMDB_API_KEY = import.meta.env.VITE_TMDB_API_KEY;
const OMDB_API_KEY = import.meta.env.VITE_OMDB_API_KEY;
const WATCHMODE_API_KEY = import.meta.env.VITE_WATCHMODE_API_KEY;

/**
 * Search for movies by title
 * @param {string} query - Movie title to search
 * @param {number} page - Page number for pagination
 * @returns {Promise<Object>} Search results from TMDB
 */
export const searchMovies = async (query, page = 1) => {
  try {
    const response = await fetch(
      `${TMDB_BASE_URL}/search/movie?api_key=${TMDB_API_KEY}&query=${encodeURIComponent(query)}&page=${page}`
    );
    
    if (!response.ok) throw new Error('Failed to search movies');
    return await response.json();
  } catch (error) {
    console.error('Error searching movies:', error);
    throw error;
  }
};

/**
 * Get popular movies
 * @param {number} page - Page number
 * @returns {Promise<Object>} Popular movies
 */
export const getPopularMovies = async (page = 1) => {
  try {
    const response = await fetch(
      `${TMDB_BASE_URL}/movie/popular?api_key=${TMDB_API_KEY}&page=${page}`
    );
    
    if (!response.ok) throw new Error('Failed to fetch popular movies');
    return await response.json();
  } catch (error) {
    console.error('Error fetching popular movies:', error);
    throw error;
  }
};

/**
 * Get trending movies
 * @param {string} timeWindow - 'day' or 'week'
 * @returns {Promise<Object>} Trending movies
 */
export const getTrendingMovies = async (timeWindow = 'week') => {
  try {
    const response = await fetch(
      `${TMDB_BASE_URL}/trending/movie/${timeWindow}?api_key=${TMDB_API_KEY}`
    );
    
    if (!response.ok) throw new Error('Failed to fetch trending movies');
    return await response.json();
  } catch (error) {
    console.error('Error fetching trending movies:', error);
    throw error;
  }
};

/**
 * Get detailed movie information from TMDB
 * @param {number} movieId - TMDB movie ID
 * @returns {Promise<Object>} Detailed movie data
 */
export const getMovieDetails = async (movieId) => {
  try {
    const response = await fetch(
      `${TMDB_BASE_URL}/movie/${movieId}?api_key=${TMDB_API_KEY}&append_to_response=credits,videos,watch/providers`
    );
    
    if (!response.ok) throw new Error('Failed to fetch movie details');
    return await response.json();
  } catch (error) {
    console.error('Error fetching movie details:', error);
    throw error;
  }
};

/**
 * Get IMDb and Rotten Tomatoes ratings from OMDb
 * @param {string} imdbId - IMDb ID (e.g., 'tt1375666')
 * @returns {Promise<Object>} Ratings data including RT scores
 */
export const getOMDbRatings = async (imdbId) => {
  try {
    const response = await fetch(
      `${OMDB_BASE_URL}/?apikey=${OMDB_API_KEY}&i=${imdbId}&plot=short`
    );
    
    if (!response.ok) throw new Error('Failed to fetch OMDb data');
    const data = await response.json();
    
    // Extract ratings
    const imdbRating = parseFloat(data.imdbRating) || 0;
    const rtRating = data.Ratings?.find(r => r.Source === 'Rotten Tomatoes')?.Value || 'N/A';
    const metacritic = data.Ratings?.find(r => r.Source === 'Metacritic')?.Value || 'N/A';
    
    return {
      imdbRating,
      imdbVotes: data.imdbVotes,
      rottenTomatoes: rtRating,
      metacritic,
      rated: data.Rated,
      runtime: data.Runtime,
      awards: data.Awards
    };
  } catch (error) {
    console.error('Error fetching OMDb ratings:', error);
    // Return defaults if OMDb fails
    return {
      imdbRating: 0,
      imdbVotes: 'N/A',
      rottenTomatoes: 'N/A',
      metacritic: 'N/A',
      rated: 'N/A',
      runtime: 'N/A',
      awards: 'N/A'
    };
  }
};

/**
 * Get streaming availability from Watchmode
 * @param {string} title - Movie title
 * @param {number} year - Release year
 * @returns {Promise<Object>} Streaming platform data
 */
export const getStreamingAvailability = async (title, year) => {
  try {
    // First search for the title
    const searchResponse = await fetch(
      `${WATCHMODE_BASE_URL}/autocomplete-search/?apiKey=${WATCHMODE_API_KEY}&search_value=${encodeURIComponent(title)}&search_type=1`
    );
    
    if (!searchResponse.ok) throw new Error('Failed to search Watchmode');
    const searchData = await searchResponse.json();
    
    // Find the matching title by year
    const match = searchData.results?.find(r => 
      r.year === year || Math.abs(r.year - year) <= 1
    );
    
    if (!match) return { platforms: [] };
    
    // Get detailed info including streaming sources
    const detailsResponse = await fetch(
      `${WATCHMODE_BASE_URL}/title/${match.id}/details/?apiKey=${WATCHMODE_API_KEY}`
    );
    
    if (!detailsResponse.ok) throw new Error('Failed to fetch Watchmode details');
    const details = await detailsResponse.json();
    
    return {
      platforms: details.sources || [],
      watchmodeId: match.id
    };
  } catch (error) {
    console.error('Error fetching streaming availability:', error);
    return { platforms: [] };
  }
};

/**
 * Discover movies with filters
 * @param {Object} filters - Filter parameters
 * @returns {Promise<Object>} Filtered movie results
 */
export const discoverMovies = async (filters = {}) => {
  const {
    genres = [],
    yearMin = 1970,
    yearMax = new Date().getFullYear(),
    voteAverageMin = 0,
    runtimeMin = 0,
    runtimeMax = 400,
    sortBy = 'popularity.desc',
    page = 1,
    withWatchProviders = [],
    watchRegion = 'US'
  } = filters;

  try {
    // Build query parameters
    const params = new URLSearchParams({
      api_key: TMDB_API_KEY,
      sort_by: sortBy,
      page: page.toString(),
      'primary_release_date.gte': `${yearMin}-01-01`,
      'primary_release_date.lte': `${yearMax}-12-31`,
      'vote_average.gte': voteAverageMin.toString(),
      'with_runtime.gte': runtimeMin.toString(),
      'with_runtime.lte': runtimeMax.toString(),
      watch_region: watchRegion
    });

    // Add genres if specified
    if (genres.length > 0) {
      params.append('with_genres', genres.join(','));
    }

    // Add streaming providers if specified
    if (withWatchProviders.length > 0) {
      params.append('with_watch_providers', withWatchProviders.join('|'));
    }

    const response = await fetch(
      `${TMDB_BASE_URL}/discover/movie?${params.toString()}`
    );
    
    if (!response.ok) throw new Error('Failed to discover movies');
    return await response.json();
  } catch (error) {
    console.error('Error discovering movies:', error);
    throw error;
  }
};

/**
 * Get similar movies
 * @param {number} movieId - TMDB movie ID
 * @returns {Promise<Object>} Similar movies
 */
export const getSimilarMovies = async (movieId) => {
  try {
    const response = await fetch(
      `${TMDB_BASE_URL}/movie/${movieId}/similar?api_key=${TMDB_API_KEY}`
    );
    
    if (!response.ok) throw new Error('Failed to fetch similar movies');
    return await response.json();
  } catch (error) {
    console.error('Error fetching similar movies:', error);
    throw error;
  }
};

/**
 * Get movie recommendations based on a movie
 * @param {number} movieId - TMDB movie ID
 * @returns {Promise<Object>} Recommended movies
 */
export const getRecommendations = async (movieId) => {
  try {
    const response = await fetch(
      `${TMDB_BASE_URL}/movie/${movieId}/recommendations?api_key=${TMDB_API_KEY}`
    );
    
    if (!response.ok) throw new Error('Failed to fetch recommendations');
    return await response.json();
  } catch (error) {
    console.error('Error fetching recommendations:', error);
    throw error;
  }
};

/**
 * Get complete movie data combining TMDB, OMDb, and streaming info
 * @param {number} tmdbId - TMDB movie ID
 * @returns {Promise<Object>} Complete movie data
 */
export const getCompleteMovieData = async (tmdbId) => {
  try {
    // Get TMDB details first
    const tmdbData = await getMovieDetails(tmdbId);
    
    // Get OMDb ratings if we have IMDb ID
    let omdbData = {};
    if (tmdbData.imdb_id) {
      omdbData = await getOMDbRatings(tmdbData.imdb_id);
    }
    
    // Get streaming availability
    const streamingData = await getStreamingAvailability(
      tmdbData.title,
      new Date(tmdbData.release_date).getFullYear()
    );
    
    // Combine all data
    return {
      id: tmdbData.id,
      title: tmdbData.title,
      overview: tmdbData.overview,
      posterPath: tmdbData.poster_path,
      backdropPath: tmdbData.backdrop_path,
      releaseDate: tmdbData.release_date,
      year: new Date(tmdbData.release_date).getFullYear(),
      genres: tmdbData.genres,
      runtime: tmdbData.runtime,
      
      // Ratings from multiple sources
      tmdbRating: tmdbData.vote_average,
      tmdbVotes: tmdbData.vote_count,
      imdbRating: omdbData.imdbRating,
      imdbVotes: omdbData.imdbVotes,
      rottenTomatoes: omdbData.rottenTomatoes,
      metacritic: omdbData.metacritic,
      
      // Additional info
      contentRating: omdbData.rated || tmdbData.release_dates?.results?.[0]?.release_dates?.[0]?.certification,
      cast: tmdbData.credits?.cast?.slice(0, 10) || [],
      director: tmdbData.credits?.crew?.find(person => person.job === 'Director'),
      
      // Streaming platforms
      streamingPlatforms: streamingData.platforms,
      watchProviders: tmdbData['watch/providers']?.results?.US || {},
      
      // Video trailers
      trailers: tmdbData.videos?.results?.filter(v => v.type === 'Trailer') || []
    };
  } catch (error) {
    console.error('Error fetching complete movie data:', error);
    throw error;
  }
};

/**
 * Helper function to build image URL
 * @param {string} path - Image path from TMDB
 * @param {string} size - Image size (w92, w154, w185, w342, w500, w780, original)
 * @returns {string} Full image URL
 */
export const getImageUrl = (path, size = 'w500') => {
  if (!path) return null;
  return `${TMDB_IMAGE_BASE}/${size}${path}`;
};

/**
 * Get TMDB genre list
 * @returns {Promise<Object>} Genre list
 */
export const getGenres = async () => {
  try {
    const response = await fetch(
      `${TMDB_BASE_URL}/genre/movie/list?api_key=${TMDB_API_KEY}`
    );
    
    if (!response.ok) throw new Error('Failed to fetch genres');
    return await response.json();
  } catch (error) {
    console.error('Error fetching genres:', error);
    throw error;
  }
};

/**
 * Get available streaming providers
 * @param {string} region - Country code (e.g., 'US')
 * @returns {Promise<Object>} Available providers
 */
export const getStreamingProviders = async (region = 'US') => {
  try {
    const response = await fetch(
      `${TMDB_BASE_URL}/watch/providers/movie?api_key=${TMDB_API_KEY}&watch_region=${region}`
    );
    
    if (!response.ok) throw new Error('Failed to fetch providers');
    return await response.json();
  } catch (error) {
    console.error('Error fetching streaming providers:', error);
    throw error;
  }
};

// Map TMDB provider IDs to common names
export const PROVIDER_MAP = {
  8: { name: 'Netflix', id: 'netflix' },
  15: { name: 'Hulu', id: 'hulu' },
  337: { name: 'Disney+', id: 'disney' },
  384: { name: 'HBO Max', id: 'hbo' },
  9: { name: 'Prime Video', id: 'prime' },
  350: { name: 'Apple TV+', id: 'apple' },
  531: { name: 'Paramount+', id: 'paramount' },
  386: { name: 'Peacock', id: 'peacock' }
};
