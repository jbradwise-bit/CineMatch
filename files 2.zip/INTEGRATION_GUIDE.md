# 🔌 API Integration Guide

This guide shows you how to integrate real movie data into CineMatch after getting your API keys.

## 📝 Step-by-Step Integration

### Step 1: Set Up Environment Variables

1. Copy `.env.example` to `.env`:
   ```bash
   cp .env.example .env
   ```

2. Add your API keys to `.env`:
   ```env
   VITE_TMDB_API_KEY=abc123your_actual_key
   VITE_OMDB_API_KEY=xyz789your_actual_key
   VITE_WATCHMODE_API_KEY=def456your_actual_key
   ```

3. Restart your dev server:
   ```bash
   npm run dev
   ```

### Step 2: Import the API Service

In your `App.jsx`, import the API functions:

```javascript
import {
  getPopularMovies,
  getTrendingMovies,
  discoverMovies,
  getCompleteMovieData,
  getImageUrl,
  searchMovies
} from './services/movieApi';
```

### Step 3: Replace Sample Data

#### For Profile Builder (Popular Movies):

Replace the `sampleMovies` array with real data:

```javascript
const [sampleMovies, setSampleMovies] = useState([]);
const [loading, setLoading] = useState(true);

useEffect(() => {
  const fetchPopularMovies = async () => {
    try {
      setLoading(true);
      const data = await getPopularMovies();
      
      // Transform TMDB data to our format
      const movies = await Promise.all(
        data.results.slice(0, 10).map(async (movie) => {
          // Get additional data (OMDb ratings, etc.)
          const fullData = await getCompleteMovieData(movie.id);
          
          return {
            id: movie.id,
            title: movie.title,
            year: new Date(movie.release_date).getFullYear(),
            poster: getImageUrl(movie.poster_path, 'w500'),
            genre: fullData.genres.map(g => g.name),
            imdb: fullData.imdbRating,
            rt: fullData.rottenTomatoes,
            runtime: fullData.runtime,
            rating: fullData.contentRating,
            platform: 'netflix' // You'll get this from streaming API
          };
        })
      );
      
      setSampleMovies(movies);
    } catch (error) {
      console.error('Error fetching movies:', error);
    } finally {
      setLoading(false);
    }
  };

  fetchPopularMovies();
}, []);
```

#### For Discovery View (Filtered Results):

Update the movie grid to use real filtered data:

```javascript
const [discoveredMovies, setDiscoveredMovies] = useState([]);

useEffect(() => {
  const fetchFilteredMovies = async () => {
    try {
      const genreIds = await getGenreIds(filters.genres); // Helper function
      
      const data = await discoverMovies({
        genres: genreIds,
        yearMin: filters.yearMin,
        yearMax: filters.yearMax,
        voteAverageMin: filters.imdbMin,
        runtimeMin: filters.runtimeMin,
        runtimeMax: filters.runtimeMax,
        withWatchProviders: getProviderIds(filters.platforms)
      });
      
      setDiscoveredMovies(data.results);
    } catch (error) {
      console.error('Error discovering movies:', error);
    }
  };

  fetchFilteredMovies();
}, [filters]); // Re-fetch when filters change
```

#### Add Search Functionality:

```javascript
const [searchQuery, setSearchQuery] = useState('');
const [searchResults, setSearchResults] = useState([]);

const handleSearch = async (query) => {
  if (!query.trim()) return;
  
  try {
    const data = await searchMovies(query);
    setSearchResults(data.results);
  } catch (error) {
    console.error('Error searching:', error);
  }
};
```

### Step 4: Genre ID Mapping

Create a helper to convert genre names to TMDB IDs:

```javascript
// Genre mapping (from TMDB)
const GENRE_MAP = {
  'Action': 28,
  'Adventure': 12,
  'Animation': 16,
  'Comedy': 35,
  'Crime': 80,
  'Documentary': 99,
  'Drama': 18,
  'Family': 10751,
  'Fantasy': 14,
  'History': 36,
  'Horror': 27,
  'Music': 10402,
  'Mystery': 9648,
  'Romance': 10749,
  'Science Fiction': 878,
  'Sci-Fi': 878,
  'TV Movie': 10770,
  'Thriller': 53,
  'War': 10752,
  'Western': 37
};

const getGenreIds = (genreNames) => {
  return genreNames.map(name => GENRE_MAP[name]).filter(Boolean);
};
```

### Step 5: Streaming Provider Mapping

```javascript
// Map your UI provider IDs to TMDB provider IDs
const PROVIDER_IDS = {
  'netflix': 8,
  'hulu': 15,
  'disney': 337,
  'hbo': 384,
  'prime': 9,
  'apple': 350,
  'paramount': 531,
  'peacock': 386
};

const getProviderIds = (platformIds) => {
  return platformIds.map(id => PROVIDER_IDS[id]).filter(Boolean);
};
```

### Step 6: Add Loading States

```javascript
{loading ? (
  <div style={{
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: '400px',
    color: '#FFF'
  }}>
    <div>Loading amazing movies...</div>
  </div>
) : (
  // Your movie grid here
)}
```

### Step 7: Error Handling

```javascript
const [error, setError] = useState(null);

try {
  // API call
} catch (err) {
  setError('Failed to load movies. Please try again.');
  console.error(err);
}

// Display error
{error && (
  <div style={{
    background: 'rgba(255,68,68,0.2)',
    border: '1px solid #FF4444',
    borderRadius: '12px',
    padding: '20px',
    color: '#FF4444',
    textAlign: 'center'
  }}>
    {error}
  </div>
)}
```

## 🎯 Advanced Features

### Caching to Reduce API Calls

```javascript
// Simple localStorage caching
const CACHE_DURATION = 1000 * 60 * 60; // 1 hour

const getCachedData = (key) => {
  const cached = localStorage.getItem(key);
  if (!cached) return null;
  
  const { data, timestamp } = JSON.parse(cached);
  if (Date.now() - timestamp > CACHE_DURATION) {
    localStorage.removeItem(key);
    return null;
  }
  
  return data;
};

const setCachedData = (key, data) => {
  localStorage.setItem(key, JSON.stringify({
    data,
    timestamp: Date.now()
  }));
};

// Usage
const fetchPopularMovies = async () => {
  const cached = getCachedData('popular_movies');
  if (cached) {
    setSampleMovies(cached);
    return;
  }
  
  const data = await getPopularMovies();
  setCachedData('popular_movies', data);
  setSampleMovies(data);
};
```

### Infinite Scroll / Pagination

```javascript
const [page, setPage] = useState(1);
const [hasMore, setHasMore] = useState(true);

const loadMore = async () => {
  const data = await discoverMovies({ ...filters, page: page + 1 });
  setDiscoveredMovies(prev => [...prev, ...data.results]);
  setPage(prev => prev + 1);
  setHasMore(data.page < data.total_pages);
};

// Add scroll listener
useEffect(() => {
  const handleScroll = () => {
    if (
      window.innerHeight + window.scrollY >= document.body.offsetHeight - 500 &&
      hasMore &&
      !loading
    ) {
      loadMore();
    }
  };
  
  window.addEventListener('scroll', handleScroll);
  return () => window.removeEventListener('scroll', handleScroll);
}, [hasMore, loading]);
```

### Personalized Recommendations

```javascript
// Build recommendation algorithm based on user preferences
const getPersonalizedRecommendations = async (userPreferences) => {
  const { loved, liked } = userPreferences;
  
  // Get similar movies for loved ones
  const recommendations = [];
  
  for (const movieId of loved.slice(0, 3)) {
    const similar = await getSimilarMovies(movieId);
    recommendations.push(...similar.results);
  }
  
  // Remove duplicates and already rated
  const unique = recommendations.filter((movie, index, self) =>
    index === self.findIndex(m => m.id === movie.id) &&
    !loved.includes(movie.id) &&
    !liked.includes(movie.id)
  );
  
  return unique.slice(0, 20);
};
```

## 🔒 Production Deployment with API Keys

### For Netlify:

1. Go to your Netlify site dashboard
2. Click "Site settings" → "Environment variables"
3. Add each variable:
   - Key: `VITE_TMDB_API_KEY`
   - Value: Your actual API key
4. Repeat for all API keys
5. Redeploy your site

### For Vercel:

1. Go to project settings
2. Click "Environment Variables"
3. Add each variable for "Production" environment
4. Redeploy

**Important:** Never commit `.env` file to Git!

## 📊 API Call Optimization Tips

1. **Batch requests** - Load multiple movies at once
2. **Debounce search** - Wait 300ms after user stops typing
3. **Cache images** - Posters don't change
4. **Lazy load** - Only fetch visible movies
5. **Prefetch** - Load next page in background
6. **Error fallbacks** - Show cached data if API fails

## 🧪 Testing Your Integration

```javascript
// Test TMDB connection
import { getPopularMovies } from './services/movieApi';

getPopularMovies()
  .then(data => console.log('✅ TMDB working:', data.results.length, 'movies'))
  .catch(err => console.error('❌ TMDB error:', err));

// Test OMDb connection
import { getOMDbRatings } from './services/movieApi';

getOMDbRatings('tt1375666') // Inception
  .then(data => console.log('✅ OMDb working:', data))
  .catch(err => console.error('❌ OMDb error:', err));
```

## 🎬 You're Ready!

Once you have your API keys and follow these steps, your app will have:
- ✅ Real movie data with posters
- ✅ Accurate IMDb & Rotten Tomatoes ratings
- ✅ Current streaming availability
- ✅ Smart recommendations
- ✅ Advanced filtering

The APIs are very reliable and fast - your app will feel professional and polished!
