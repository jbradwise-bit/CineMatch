# 🔑 API Setup Guide for CineMatch

This guide will walk you through getting API access for all the movie data services you need.

## 📋 Required APIs

### 1. **TMDB (The Movie Database)** - PRIMARY API ⭐
**What it provides:**
- Movie posters and images (high quality)
- Plot summaries, cast, crew
- Release dates, runtime
- User ratings
- Genre information
- Streaming availability (via JustWatch integration)
- Trending movies
- Similar movie recommendations

**Cost:** FREE (up to 1 million requests/month)

**How to get API key:**
1. Go to https://www.themoviedb.org/signup
2. Create a free account
3. Verify your email
4. Go to https://www.themoviedb.org/settings/api
5. Click "Request an API Key"
6. Select "Developer"
7. Fill out the form (use "Personal/Educational" if non-commercial)
8. Accept terms and submit
9. **Copy your API Key (v3 auth)** - you'll get it instantly!

**API Documentation:** https://developers.themoviedb.org/3

**Example endpoints:**
- Search movies: `https://api.themoviedb.org/3/search/movie?api_key=YOUR_KEY&query=inception`
- Get movie details: `https://api.themoviedb.org/3/movie/550?api_key=YOUR_KEY`
- Get posters: `https://image.tmdb.org/t/p/w500/POSTER_PATH.jpg`

---

### 2. **OMDb API (Open Movie Database)** - FOR IMDB & RT RATINGS
**What it provides:**
- IMDb ratings and votes
- Rotten Tomatoes scores (Tomatometer & Audience Score)
- Metacritic scores
- Awards and nominations
- Box office data

**Cost:** 
- FREE: 1,000 requests/day
- $1/month: 100,000 requests/month (unlimited daily)

**How to get API key:**
1. Go to http://www.omdbapi.com/apikey.aspx
2. Select FREE plan (1,000 daily requests)
3. Enter your email
4. Check your email and click activation link
5. **Copy your API key** from the email

**API Documentation:** http://www.omdbapi.com/

**Example endpoint:**
- `http://www.omdbapi.com/?apikey=YOUR_KEY&i=tt1375666&plot=full`
- `http://www.omdbapi.com/?apikey=YOUR_KEY&t=Inception&type=movie`

---

### 3. **Streaming Availability API** - FOR PLATFORM AVAILABILITY
**What it provides:**
- Which streaming services have each movie/show
- Netflix, Hulu, Disney+, HBO Max, Prime Video, Apple TV+, etc.
- Available countries
- Pricing information
- Deep links to streaming platforms

**Cost:**
- FREE: 100 requests/month
- Basic ($9.99/month): 10,000 requests/month
- Pro ($99/month): 100,000 requests/month

**How to get API key:**
1. Go to https://rapidapi.com/movie-of-the-night-movie-of-the-night-default/api/streaming-availability
2. Click "Sign Up" (create RapidAPI account)
3. Subscribe to FREE plan
4. Go to "Endpoints" tab
5. **Copy your RapidAPI Key** from the header section

**API Documentation:** https://rapidapi.com/movie-of-the-night-movie-of-the-night-default/api/streaming-availability

**Example endpoint:**
```
GET https://streaming-availability.p.rapidapi.com/get
Headers:
  X-RapidAPI-Key: YOUR_RAPIDAPI_KEY
  X-RapidAPI-Host: streaming-availability.p.rapidapi.com
Params:
  tmdb_id=movie/550
  output_language=en
```

---

### 4. **Alternative: Watchmode API** - SIMPLER STREAMING DATA
**What it provides:**
- Streaming availability across 100+ services
- Title search
- Pricing and rental information
- Region-specific availability

**Cost:**
- FREE: 1,000 requests/month
- Paid: Starting at $8/month for 10,000 requests

**How to get API key:**
1. Go to https://api.watchmode.com/
2. Click "Get API Key"
3. Sign up with email
4. Verify email
5. **Copy API key** from dashboard

**API Documentation:** https://api.watchmode.com/docs/

---

## 🎯 Recommended Setup (Best Free Tier)

**For personal/learning projects:**
1. **TMDB** - FREE (1M requests/month) - Primary movie data & images
2. **OMDb** - FREE (1,000/day) - IMDb & Rotten Tomatoes scores
3. **Watchmode** - FREE (1,000/month) - Streaming availability

This gives you:
- ✅ All movie metadata
- ✅ High-quality posters
- ✅ IMDb ratings
- ✅ Rotten Tomatoes scores
- ✅ Streaming platform info
- ✅ Zero monthly cost

**For production app:**
- Upgrade OMDb to $1/month (100k requests)
- Upgrade Watchmode to $8/month if needed
- Keep TMDB free (1M is plenty)

---

## 🔐 Setting Up Your Environment Variables

Once you have your API keys, create a `.env` file in your project root:

```env
# TMDB API
VITE_TMDB_API_KEY=your_tmdb_api_key_here
VITE_TMDB_ACCESS_TOKEN=your_tmdb_access_token_here

# OMDb API (for IMDb & RT ratings)
VITE_OMDB_API_KEY=your_omdb_api_key_here

# Streaming Availability (choose one)
VITE_RAPIDAPI_KEY=your_rapidapi_key_here
# OR
VITE_WATCHMODE_API_KEY=your_watchmode_api_key_here
```

**IMPORTANT SECURITY NOTES:**
1. ✅ Add `.env` to your `.gitignore` (already done)
2. ✅ NEVER commit API keys to GitHub
3. ✅ For production, use environment variables in Netlify/Vercel dashboard
4. ⚠️ Frontend API keys are visible to users - use backend proxy for sensitive operations

---

## 🛡️ Protecting Your API Keys in Production

### Option 1: Use Netlify Functions (Recommended)
Create serverless functions to proxy API requests:

```javascript
// netlify/functions/get-movie.js
exports.handler = async (event) => {
  const { movieId } = event.queryStringParameters;
  
  const response = await fetch(
    `https://api.themoviedb.org/3/movie/${movieId}?api_key=${process.env.TMDB_API_KEY}`
  );
  
  return {
    statusCode: 200,
    body: JSON.stringify(await response.json())
  };
};
```

### Option 2: Build a Simple Backend
- Use Express.js, FastAPI, or similar
- Deploy on Heroku, Railway, or Render (free tiers available)
- Keep API keys server-side only

---

## 📊 API Rate Limits Summary

| API | Free Tier | Requests/Month | Best For |
|-----|-----------|----------------|----------|
| **TMDB** | ✅ FREE | 1,000,000 | Movie data, posters, search |
| **OMDb** | ✅ FREE | ~30,000 (1k/day) | IMDb & RT ratings |
| **Watchmode** | ✅ FREE | 1,000 | Streaming availability |
| **Streaming Availability** | ✅ FREE | 100 | Limited testing only |

---

## 🧪 Testing Your API Keys

After getting your keys, test them:

### Test TMDB:
```bash
curl "https://api.themoviedb.org/3/movie/550?api_key=YOUR_KEY"
```

### Test OMDb:
```bash
curl "http://www.omdbapi.com/?apikey=YOUR_KEY&t=Inception"
```

### Test Watchmode:
```bash
curl "https://api.watchmode.com/v1/title/3173903/details/?apiKey=YOUR_KEY"
```

If you get JSON responses (not errors), you're ready to go! ✅

---

## 🚀 Next Steps

1. ✅ Get your API keys using the guides above
2. ✅ Create `.env` file with your keys
3. ✅ Test each API endpoint
4. ✅ Integrate into your app (I'll provide updated code)
5. ✅ Deploy with environment variables configured

---

## ❓ Common Issues & Solutions

**Q: TMDB images not loading?**
- Use full URL: `https://image.tmdb.org/t/p/w500${posterPath}`
- Check if posterPath exists in response

**Q: OMDb not returning Rotten Tomatoes?**
- Not all movies have RT scores
- Check the `Ratings` array in response

**Q: Streaming data seems outdated?**
- Streaming availability changes frequently
- Cache for 24-48 hours max
- Use TMDB's Watch Providers endpoint as alternative

**Q: Hit rate limits?**
- Implement caching (localStorage, Redis)
- Use pagination efficiently
- Consider upgrading to paid tier

**Q: CORS errors?**
- Use serverless functions or backend proxy
- Most movie APIs support CORS, but check docs

---

## 💡 Pro Tips

1. **Cache aggressively** - Movie metadata doesn't change often
2. **Lazy load images** - Use IntersectionObserver for posters
3. **Batch requests** - Combine multiple movie IDs when possible
4. **Error handling** - Always handle rate limits and API failures
5. **Fallback data** - Show sample/cached data if APIs are down

---

Ready to integrate? Let me know when you have your API keys and I'll update the app code to use real data! 🎬
